export class Employee {
  constructor(name, surname) {
    this.name = name;
    this.surname = surname;
  }
}


